
# tcpserver Trigger

This trigger reads/writes data using TCP networks.
